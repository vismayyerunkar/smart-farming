import React from 'react';
import '../../styles/About.css'

function About() {
  return (
    <div>
        about 
    </div>
  )
}

export default About;